function y = f(theta)

% Example 1
y = abs(cos(theta));
%y = (sin(theta).*sin(5*pi.*cos(theta)))./(5*pi.*cos(theta));

%y=(sin(theta).*sin(5*pi*(cos(theta)-0.1)))./(5*pi*(cos(theta)-0.1));