function y = f(THETA,PHI)

% Please edit the field pattern here.
% Make sure to use dot operations(".*","./" and ".^") in the
% expression instead of regular operations("*","/" and "^")!





% Example Ej3
%y=sin(THETA);
y=cos(THETA);




