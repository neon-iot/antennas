function y = U(THETA, PHI)
%  **Example**
 % y = 1./sin(THETA).^2;
 % y = (sin(THETA).*sin(pi/2.*cos(THETA)))./(pi/2.*cos(THETA));
% y=cos(THETA).^3;% Ejercicio 1 n=3

 y=sin(THETA).*(sin(PHI)).^2;