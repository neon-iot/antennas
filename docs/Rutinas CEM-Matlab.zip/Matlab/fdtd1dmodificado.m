%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% fdtd1
% Carlos J. Cela, Jan 2012
%
% One-dimensional, free space FDTD simulation
% using a Gaussian pulse source.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all
close all

% Number of cells in Z direction
numCells = 100;
numSteps=400;
% Initialize fields to zero
Ex(numCells) = 0;
Hy(numCells) = 0;
El(numSteps) = 0;
Em(numSteps) = 0;
Es(numSteps) = 0;
% Gaussian pulse parameters
t0 = 50;     %Center of pulse
spread = 7; % Width of pulse

% Main loop (Loop C)
for t = 1:numSteps
  % (Loop A)
  % Calculate Ex field. Note that first 
  % cell is skipped in the loop, since we 
  % need to access k-1
  for k = 2:numCells
    Ex(k) = Ex(k) - 0.5*(Hy(k)-Hy(k-1));
  end
  %Ex(numCells)=0;% Condici�n de borde en el extremo para CC
  % Add E field source excitation with a Gaussian pulse.
  Ex(numCells)=0;
  Ex(1) = exp(-0.5*((t0-t)/spread)^2); % Hard source
  % (Loop B)
  % Calculate Hy field. Note that last 
  % cell is skipped in the loop, since we 
  % need to access k+1
  for k = 1:numCells-1
    Hy(k) = Hy(k) - 0.5*(Ex(k+1)-Ex(k));
  end
  % Vectores que almacenan el campo E en ambos extremos y en el medio
  El(t)=Ex(numCells);
  Em(t)=Ex(numCells/2);
  Es(t)=Ex(1);
  % Plot 
  subplot(2,1,1),
  plot(1:numCells, Ex,'r','linewidth',2);
  axis([1 numCells -2 2]);
  grid on;
  legend('Ex');
  %hold on 
  subplot(2,1,2)
  plot(1:numCells, Hy,'b','linewidth',2);
  axis([1 numCells -2 2]);
  grid on;
  hold off
  legend('Hy');
  pause(0.00001);
  
end

figure(2),
subplot(2,1,1),
  plot(1:numSteps, El,'r','linewidth',2),grid on,hold on,plot(1:numSteps, Es,'b','linewidth',2);
  axis([1 numSteps -2 2]);
  legend('El','Es');
  hold on 
  subplot(2,1,2)
  plot(1:numSteps, Em,'b','linewidth',2);
  axis([1 numSteps -2 2]);
  grid on;
  hold off
  legend('Em');




