%==========================================================================
%
%   ECE 5340/6340 homework 5.
%
%   Solve for the capacitor plate potentials using SOR.
%
%       E-field produced by two parallel capacitor plates.  The top plate
%   is at a uniform potential of +1.0 V while the bottom plate is at a
%   uniform potential of -1.0 V.  
%
%==========================================================================
%
%   James Nagel
%   Department of Electrical and Computer Engineering
%   University of Utah, Salt Lake City, Utah
%   nageljr@ieee.org
%   Copyright February 8, 2012

close all;
clear all;

%==========================================================================
%  Simulation parameters.
%==========================================================================

%  Model values.
Lx = 10;        %  x-length of simulation (m).
Ly = 10;        %  y-length of simulation (m).
h  = 0.05;      %  Grid spacing (m).
D  = 1;         %  Rod diameter (m).
p0 = 1e-12;     %  Charge density of the rod (C/m^3).

%  Set up the axes.
x = 0 : h : Lx;
y = 0 : h : Ly;
x = x - mean(x);
y = y - mean(y);

%  Axis limits.
xMin = min(x);
xMax = max(x);
yMin = min(y);
yMax = max(y);

%  Generate X-Y mesh.
[X,Y] = meshgrid(x,y);

%  Generate mesh of radial distances from the center.
R = sqrt(X.^2 + Y.^2);

%  Sample sizes.
[Ny,Nx] = size(X);

%==========================================================================
%  Prepare simulation variables.
%==========================================================================

%  Initialize matrices.
V   = zeros(Ny,Nx);         %  Potential function (V).
BC  = zeros(Ny,Nx);         %  Boundary conditions (boolean).
RHO = zeros(Ny,Nx);         %  Charge distrubution (C/m^2).
EPS = ones(Ny,Nx);          %  Dielectric constants.

%  Initialize boundary conditions.  For this simulation, they are all
%  Dirichlet boundaries.
BC(1,:)   = 1;              %  Top edge
BC(end,:) = 1;              %  Bottom edge
BC(:,1)   = 1;              %  Left edge
BC(:,end) = 1;              %  Right edge

%  Find all points within the circle at the center and fill them with the
%  charge density.
IDX = find( R <= D/2 );
RHO(IDX) = p0;

%==========================================================================
%  Numerically solve Poisson's equation for this geometry.  This should
%  take up about 95% of the run-time for this code.
%==========================================================================
V = Poisson_FDM_Solver_2D(V,BC,EPS,RHO,h);

%==========================================================================
%  Solve for the electric fields along the staggered grid.
%==========================================================================
[Ex,Ey,Emag] = staggered_2D_gradient(V,h);

%  E-field is actually the NEGATIVE of the gradient.
Ex = -Ex;
Ey = -Ey;

%  E-field axes.
xe = linspace(xMin + h/2,xMax - h/2,Nx-1);
ye = linspace(yMin + h/2,yMax - h/2,Ny-1);
[Xe,Ye] = meshgrid(xe,ye);

%  Generate a new set of axes for the quivers.
hq = 10*h;               %  Quiver grid spacing.
xq = 0 : hq : Lx ;      %  X-axis.
yq = 0 : hq : Ly ;      %  Y-axis.
xq = xq - mean(xq);
yq = yq - mean(yq);
[Xq,Yq] = meshgrid(xq,yq);

%  Interpolate the field components onto a new quiver grid.
Eqx = interp2(Xe,Ye,Ex,Xq,Yq);
Eqy = interp2(Xe,Ye,Ey,Xq,Yq);

%==========================================================================
%  Solve for the magnetic fields along the staggered grid.  Do this by
%  treating the V-marix as a set of magnetic vector potentials Az.
%==========================================================================
Az = V;
[Bx,By,Bmag] = staggered_2D_curl(Az,h);

%  Interpolate the B-field components onto a new quiver grid.
Bqx = interp2(Xe,Ye,Bx,Xq,Yq);
Bqy = interp2(Xe,Ye,By,Xq,Yq);

%==========================================================================
%   Render the potential image.
%==========================================================================
fig = figure(1);
clf
imagesc(x,y,V);
axis equal
axis([xMin xMax yMin yMax ]);
axis xy;
colormap jet;
X = xlabel('Distance (cm)');
Y = ylabel('Distance (cm)');
set(X,'fontname','verdana','fontsize',24);
set(Y,'fontname','verdana','fontsize',24);
set(gca,'fontsize',18);
title('Voltage Potential (V)','fontname','verdana','fontsize',24);

%  Tweak the figure to make it look better.
set(fig,'units','normalized','position',[0.1, 0.1, 0.5, 0.5*Ny/Nx]);

%==========================================================================
%   Render the E-field image.
%==========================================================================
fig = figure(2);
clf
imagesc(xe,ye,Emag);
axis xy
axis equal
axis([xMin xMax yMin yMax ]);
colormap jet;
X = xlabel('Distance (m)');
Y = ylabel('Distance (m)');
set(X,'fontname','verdana','fontsize',24);
set(Y,'fontname','verdana','fontsize',24);
set(gca,'fontsize',18);
title('Electric Field (V/m)','fontname','verdana','fontsize',24);

%  Make the figures look nice and pretty.
%  Tweak the figure to make it look better.
set(fig,'units','normalized','position',[0.1, 0.1, 0.5, 0.5*Ny/Nx]);

hold on
Q = center_quiver(Eqx,Eqy,hq,Xq,Yq);
set(Q,'color','k');

%==========================================================================
%   Render the B-field image.
%==========================================================================
fig = figure(3);
clf
imagesc(xe,ye,Bmag);
axis xy
axis equal
axis([xMin xMax yMin yMax ]);
colormap jet;
X = xlabel('Distance (m)');
Y = ylabel('Distance (m)');
set(X,'fontname','verdana','fontsize',24);
set(Y,'fontname','verdana','fontsize',24);
set(gca,'fontsize',18);
title('Magnetic Field (a.u.)','fontname','verdana','fontsize',24);

%  Make the figures look nice and pretty.
%  Tweak the figure to make it look better.
set(fig,'units','normalized','position',[0.1, 0.1, 0.5, 0.5*Ny/Nx]);

hold on
Q = center_quiver(Bqx,Bqy,hq,Xq,Yq);
set(Q,'color','k');




