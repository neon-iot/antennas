%==========================================================================
%
%   Centered Quiver Plot.
%
%       CENTER_QUIVER(U,V,S) behaves just like QUIVER(U,V,S), except the
%   center of the quiver is located at the grid point, rather than the
%   tail.  This is accomplished by shifting the plot location that normally
%   goes into quiver so that the tail falls into a new location.  The
%   new location is determined from the vector itself so that the center of
%   the quiver lands on the original grid point.
%
%       Note that the scale is slightly modified from the original
%   QUIVER(...) such that when S = 1, the magnitude of the largest vector
%   in U and V is normalized to a length of 1.  This causes the quiver to
%   perfectly fit the length of one plotting bin on a 2D image scale.  If
%   S = 2, then the quiver will be 2 bin lengths, and so on.
%
%       H = CENTER_QUIVER(...) returns a quivergroup handle.
%
%==========================================================================
%
%   James Nagel
%   Department of Electrical and Computer Engineering
%   University of Utah, Salt Lake City, Utah
%   nageljr@ieee.org
%   Copyright July 27, 2011

function H = center_quiver(U,V,S,X,Y)

%  Extract matrix size.
[Ny,Nx] = size(U);

%  Normalize U and V to a maximum of unit length over the domain and then
%  scale by S.
[TH,R] = cart2pol(U,V);         %  Convert U,V to polar coordinates.
Rmax   = max(R(:));             %  Maximum value in R.
R      = R*S/Rmax;              %  Normalize magnitudes.
[U V]  = pol2cart(TH,R);        %  Convert back to Cartesian.

%  Position vectors.  These matrices contain the x- and y-components of the
%  positions for the quiver tails.  By shifting these appropriately, we can
%  create the illusion of the quiver's center being placed at the desired
%  location, rather than the tail.
if nargin == 3
    X = repmat(linspace(1,Nx,Nx),Ny,1);
    Y = repmat(linspace(1,Ny,Ny),Nx,1).';
end

for n = 1:Ny
    for m = 1:Nx

        %  Extract vector.
        v = [U(n,m) V(n,m)];

        %  NaN's tend to screw things up, so this leaves NaN points alone.
        if any(isnan(v))
             X(n,m) = nan;
             Y(n,m) = nan;
            continue;
        else
            %  Move the tail coordinate so that the center of the arrow
            %  lies on the grid point. 
            X(n,m) = X(n,m) - v(1)/2;
            Y(n,m) = Y(n,m) - v(2)/2;
        end

    end
end

%  Run the default quiver function with the shifted X,Y positions.  Using
%  the zero for scale removes any automatic scaling from the result.
H = quiver(X,Y,U,V,0);




