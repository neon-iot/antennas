%==========================================================================
%
%   ECE 5340/6340 homework 5.
%
%   Solve for the capacitor plate potentials using SOR.
%
%       E-field produced by two parallel capacitor plates.  The top plate
%   is at a uniform potential of +1.0 V while the bottom plate is at a
%   uniform potential of -1.0 V.  
%
%==========================================================================
%
%   James Nagel
%   Department of Electrical and Computer Engineering
%   University of Utah, Salt Lake City, Utah
%   nageljr@ieee.org
%   Copyright February 8, 2012

close all;
clear all;

%==========================================================================
%  Simulation parameters.
%==========================================================================

%  Model values.
Lx = 10;            %  x-length of simulation (m).
Ly = 10;            %  y-length of simulation (m).
h  = 0.05;          %  Grid spacing (m).
er = 20 - 1000j;    %  Dielectric constant of object.
VL = 1;             %  Left point voltage (V).
VR = -1;            %  Right point voltage (V).
f  = 1;             %  Frequency of excitation (Hz).
w  = 2*pi*f;        %  Angular frequency (rad/s).

%  Geometric values for the metal cross.
W1 = 1;         %
W2 = 2;
L1 = 8;
L2 = 7;

%  Set up the axes.
x = 0 : h : Lx;
y = 0 : h : Ly;
x = x - mean(x);
y = y - mean(y);

%  Axis limits.
xMin = min(x);
xMax = max(x);
yMin = min(y);
yMax = max(y);

%  Generate X-Y mesh.
[X,Y] = meshgrid(x,y);

%  Sample sizes.
[Ny,Nx] = size(X);

%  E-field and dielectric axes.
xe = x(1:Nx-1) + h/2;
ye = y(1:Ny-1) + h/2;
[Xe,Ye] = meshgrid(xe,ye);

%==========================================================================
%  Prepare simulation variables.
%==========================================================================

%  Initialize matrices.
V   = zeros(Ny,Nx);         %  Potential function (V).
BC  = zeros(Ny,Nx);         %  Boundary conditions (boolean).
RHO = zeros(Ny,Nx);         %  Charge distrubution (C/m^2).
EPS = ones(Ny-1,Nx-1);      %  Dielectric constants.

%  Initialize boundary conditions.  For this simulation, they are all
%  Dirichlet boundaries.
BC(1,:)   = 1;              %  Top edge
BC(end,:) = 1;              %  Bottom edge
BC(:,1)   = 1;              %  Left edge
BC(:,end) = 1;              %  Right edge

%  Generate logical conditionals to represent points inside the geometry of
%  the cross.
Cy1 = ( Ye >= -W1/2 & Ye <= W1/2 );
Cy2 = ( Ye >= -L2/2 & Ye <= L2/2 );
Cx1 = ( Xe >= -L1/2 & Xe <= L1/2 );
Cx2 = ( Xe >= -W2/2 & Xe <= W2/2 );

%  Specify the dielectric constants of the cross.
EPS( Cy1 & Cx1 ) = er;
EPS( Cy2 & Cx2 ) = er;

%  Solve for conductivity matrix.
SIG = -w*imag(EPS);

%  Find the outermost tips of the cross.
xL = find( xe > (-L1/2-h/2) & xe < (-L1/2+h/2) );
xR = find( xe > (+L1/2-h/2) & xe < (+L1/2+h/2) );
y0 = find( ye > -h/2 & ye < h/2 );

%  Specify boundary conditions.
BC(y0,xL) = 1;
BC(y0,xR) = 1;
V(y0,xL)  = VL;
V(y0,xR)  = VR;


%==========================================================================
%  Numerically solve Poisson's equation for this geometry.  This should
%  take up about 95% of the run-time for this code.
%==========================================================================
V = Poisson_FDM_Solver_2D(V,BC,EPS,RHO,h);

%==========================================================================
%  Solve for the electric fields and current density along the staggered
%  grid.
%==========================================================================
[Ex,Ey,Emag] = staggered_2D_gradient(V,h);

%  E-field is actually the NEGATIVE of the gradient.
Ex = -Ex;
Ey = -Ey;

%  Current density.
Jx = SIG.*real(Ex);
Jy = SIG.*real(Ey);
Jmag = sqrt(Jx.^2 + Jy.^2);

%  Normalize the values.
Jmax = max(Jmag(:));
Jmag = Jmag/Jmax;
Jx   = Jx/Jmax;
Jy   = Jy/Jmax;

%  Generate a new set of axes for the quivers.
hq = 3*h;               %  Quiver grid spacing.
xq = 0 : hq : Lx ;      %  X-axis.
yq = 0 : hq : Ly ;      %  Y-axis.
xq = xq - mean(xq);
yq = yq - mean(yq);
[Xq,Yq] = meshgrid(xq,yq);

%  Interpolate the field components onto a new quiver grid.
Jqx = interp2(Xe,Ye,Jx,Xq,Yq);
Jqy = interp2(Xe,Ye,Jy,Xq,Yq);

%==========================================================================
%   Render the potential image.
%==========================================================================
fig = figure(1);
clf
imagesc(x,y,real(V));
axis([xMin xMax yMin yMax ]);
axis xy;
axis equal
colormap jet;
X = xlabel('Distance (m)');
Y = ylabel('Distance (m)');
set(X,'fontname','verdana','fontsize',24);
set(Y,'fontname','verdana','fontsize',24);
set(gca,'fontsize',18);
title('Voltage Potential (V)','fontname','verdana','fontsize',24);

%  Tweak the figure to make it look better.
set(fig,'units','normalized','position',[0.1, 0.1, 0.5, 0.5*Ny/Nx]);

Jmag = Jmag/max(abs(Jmag(:)));

figure(2)
clf
imagesc(xe,ye,Jmag,[0,0.25]);
X = xlabel('Distance (m)');
Y = ylabel('Distance (m)');
set(X,'fontname','verdana','fontsize',24);
set(Y,'fontname','verdana','fontsize',24);
set(gca,'fontsize',18);
title('Current Density (A/m^2)','fontname','verdana','fontsize',24);

hold on
Q = center_quiver(real(Jqx),real(Jqy),2.5*hq,Xq,Yq);
set(Q,'color','k');




