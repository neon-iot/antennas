% FFT calculation using Matlab

fs = 100;                          % Sample frequency (Hz)
t = 0:1/fs:10-1/fs;                % 10 sec sample

E = (1.3)*sin(2*pi*15*t) ...       % 15 Hz component
  + (1.7)*sin(2*pi*40*(t-2)) ...   % 40 Hz component
  + (0.005)*randn(size(t));          % Gaussian noise;

m = length(E);          % Window length
n = pow2(nextpow2(m));  % Transform length
Edft = fft(E,n);        % DFT
f = (0:n-1)*(fs/n);     % Frequency range

% Calculate E field magnitude at each frequency
m =sqrt(real(Edft).^2+imag(Edft).^2);

plot(f,m)
xlabel('Frequency (Hz)')
ylabel('E field magnitude')
title('{\bf DFT using Matlab FFT algorithm}')
