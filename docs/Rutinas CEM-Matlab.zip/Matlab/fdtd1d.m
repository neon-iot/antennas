%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% fdtd1
% Carlos J. Cela, Jan 2012
%
% One-dimensional, free space FDTD simulation
% using a Gaussian pulse source.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all
close all

% Number of cells in Z direction
numCells = 60;

% Initialize fields to zero
Ex(numCells) = 0;
Hy(numCells) = 0;

% Gaussian pulse parameters
t0 = 40;     %Center of pulse
spread = 8; % Width of pulse

% Main loop (Loop C)
for t = 1:700

  % (Loop A)
  % Calculate Ex field. Note that first 
  % cell is skipped in the loop, since we 
  % need to access k-1
  Ex(numCells)=0
  for k = 2:numCells-1
    Ex(k) = Ex(k) - 0.5*(Hy(k)-Hy(k-1));
  end

  % Add E field source now at the center cell.
  % Excitation is a Gaussian pulse.
  Ex(numCells/2) = exp(-0.5*((t0-t)/spread)^2); % Hard source
 
  % (Loop B)
  % Calculate Hy field. Note that last 
  % cell is skipped in the loop, since we 
  % need to access k+1
  for k = 1:numCells-1
    Hy(k) = Hy(k) - 0.5*(Ex(k+1)-Ex(k));
  end

  % Plot 
  plot(1:numCells, Ex+1,'r','linewidth',2);
  hold on 
  plot(1:numCells, Hy-1,'b','linewidth',2);
  axis([1 numCells -3 3]);
  grid on;
  hold off
  legend('Ex','Hy');
  pause(0.001);
  
end






