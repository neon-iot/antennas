%==========================================================================
%   
%       NUMERICAL GRADIENT USING CENTRAL DIFFERENCES AND STAGGERED GRID.
%
%       [Ex,Ey] = staggered_2D_gradient(V) returns the field components Ex
%   and Ey by computing the numerical gradient of the potential function
%   V.  This function is different from the standard GRADIENT function in
%   Matlab in that the resultant field components are staggered from the
%   grid locations of the samples in V.  This is accomplished by applying
%   central differences along every pair of voltage steps, and then
%   averaging the results together into the staggered formation:
%
%   Central difference stencil (before averaging):
%
%       O = Voltage sample.
%       Ex = x-component of electric field sample.
%       Ey = y-component of electric field sample.
%
%                       O   Ex  O   Ex  O
%
%                       Ey      Ey      Ey             
%                       
%                       O   Ex  O   Ex  O
%
%                       Ey      Ey      Ey
%                       
%                       O   Ex  O   Ex  O
%
%   Stencil after averaging:    
%
%       * = E-field sample.
%
%                       O       O       O
%
%                           *       *                    
%                       
%                       O       O       O
%
%                           *       *
%                       
%                       O       O       O
%
%       IMPORTANT:  The resultant E-field matrices are one unit LESS than
%   the voltage matrix in size.  That is, if size(V) = [Ny, Nx], then
%   size(Ex) = size(Ey) = [Ny-1, Nx-1].
%
%       [Ex,Ey,Emag] = staggered_gradient(V) also returns the magnitudes of
%   the E-fields.
%
%       [Ex,Ey,Emag] = staggered_gradient(V,h) assumes a value of h for the
%   grid spacing step size.  Otherwise, the default value is 1.
%
%==========================================================================
%
%   James Nagel
%   Department of Electrical and Computer Engineering
%   University of Utah, Salt Lake City, Utah
%   nageljr@ieee.org
%   Copyright October 12, 2010

function [Ex,Ey,Emag] = staggered_2D_gradient(V,h)

%  Default step size for numerical derivative.
if nargin == 1
    h = 1;
end

%  Extract size of potential matrix.
[Ny,Nx] = size(V);

%  Instantiate E-field matrices.
Ex = zeros(Ny,Nx-1);            %  x-component.
Ey = zeros(Ny-1,Nx);            %  y-component.

%  Compute x-component of E-fields.
for y = 1:Ny
    Ex(y,:) = (1/h)*diff(V(y,:));
end

%  Average Ex along the y-grid.
for y = 1:Ny-1
    Ex(y,:) = (0.5)*(Ex(y,:) + Ex(y+1,:));
end

%  Compute y-component of E-fields.
for x = 1:Nx
    Ey(:,x) = (1/h)*diff(V(:,x));
end

%  Average Ey along the x-grid.
for x = 1:Nx-1
    Ey(:,x) = (0.5)*(Ey(:,x) + Ey(:,x+1));
end

%  Drop the values at the final row/column.
Ex = Ex(1:end-1,:);
Ey = Ey(:,1:end-1);

%  Compute magnitude.
if nargout == 3
    Emag = sqrt(Ex.^2 + Ey.^2);
end


