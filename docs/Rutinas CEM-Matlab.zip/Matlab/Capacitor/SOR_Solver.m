%==========================================================================
%
%  Basic SOR solver for the Poisson/Laplace equation.
%
%   INPUTS:
%       V = Initial voltage potential matrix.
%      BC = Boundary condition matrix.
%     RHO = Charge density matrix.
%       h = Grid spacing.
%      ww = Relaxation factor.
%      Ni = Total number of iterations before giving up.
%
%==========================================================================
%
%   James Nagel
%   Department of Electrical and Computer Engineering
%   University of Utah, Salt Lake City, Utah
%   nageljr@ieee.org
%   Copyright February 6, 2012

function V = SOR_Solver(V,BC,RHO,h,ww,Ni)

%  Convert the dielectric constants to a permittivity matrix.
EPS_0 = 8.854e-12;          %  Permittivity of free-space (F/m).

%  Maximum Error
maxError = 1e-6;

%  Extract simulation domain size.
[Ny,Nx] = size(V);

%  b-matrix for SOR.
b = RHO*h^2./EPS_0;

%==========================================================================
% Begin SOR algorithm.
%==========================================================================
for n = 1:Ni
    
    %  Reset the maximum value of the residual.
    maxR = 0;
    
    %  Scan along rows (y).
    for jj = 1:Ny
        
        %  Scan along columns (x).
        for ii = 1:Nx
            
            %  First check for a Dirichlet boundary.  If it is, then skip
            %  over this point to the next.
            if ( BC(jj,ii) == 1 )
                continue;
            end
            
            %  Check for Neumann boundaries.
            %
            if ( jj == 1 )  %  Bottom boundary
                V(jj,ii) = V(jj + 1,ii);
                continue;
            end
            
            if ( jj == Ny )  %  Top boundary
                V(jj,ii) = V(jj - 1,ii);
                continue;
            end
            
            if ( ii == 1 )  %  Left boundary
                V(jj,ii) = V(jj,ii + 1);
                continue;
            end
            
            if ( ii == Nx )  %  Right boundary
                V(jj,ii) = V(jj,ii - 1);
                continue;
            end
            
            %  If none of the boundary ocnditions are set off, then
            %  calculate the residual using 5-point star.
            R =  0.25 * ( V(jj+1,ii) + V(jj-1,ii) ...
                + V(jj,ii+1) + V(jj,ii-1) ...
                + b(jj,ii) ) - V(jj,ii) ;
            
            %  Update the potential matrix.
            V(jj,ii) = V(jj,ii) + ww*R;
            
            %  Maximum value of the residual.
            maxR = max(maxR,abs(R));
        end
        
    end
    
    %  Break the loop if hardly anything is changing (convergence).
    if maxR < maxError
        disp(n);
        break;
    end
    
    %  Display progress
    if (mod(n,100) == 0 )
        disp(['Iteration: ', num2str(n)]);
    end
    
    %     %  For debugging only...
    %     imagesc(V);
    %     drawnow;
    
    
end

return;


