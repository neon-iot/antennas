%==========================================================================
%
%
%==========================================================================
%
%   James Nagel
%   Department of Electrical and Computer Engineering
%   University of Utah, Salt Lake City, Utah
%   nageljr@ieee.org
%   Copyright February 8, 2012

close all;
clear all;


ww = 1.5:0.05:1.95 ;

I = [926,822,723,629,539,453,369,287,204,330];

figure(1)
clf
plot(ww,I,'-k');
X = xlabel('Relaxation Factor (\omega)');
Y = ylabel('Iterations');
set(X,'fontname','verdana','fontsize',24);
set(Y,'fontname','verdana','fontsize',24);

