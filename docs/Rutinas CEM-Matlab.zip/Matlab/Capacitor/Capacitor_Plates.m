%==========================================================================
%
%   Generate Example 2 for my FDM notes.
%
%       E-field produced by two parallel capacitor plates.  The top plate
%   is at a uniform potential of +1.0 V while the bottom plate is at a
%   uniform potential of -1.0 V.  
%
%   Required functions:
%       center_quiver.m
%       Poisson_FDM_Solver_2D.m
%       staggered_2D_gradient.m
%
%==========================================================================
%
%   James Nagel
%   Department of Electrical and Computer Engineering
%   University of Utah, Salt Lake City, Utah
%   nageljr@ieee.org
%   Copyright February 8, 2012

close all;
clear all;

%==========================================================================
%  Simulation parameters.
%==========================================================================

%  Simulation domain size (m).
Lx = 2.0;
Ly = 1.0;

%  Grid spacing (m).
h = 0.01;

%  Generate axes.
x = 0 : h : Lx ;
y = 0 : h : Ly ;
x = x - mean(x);
y = y - mean(y);
[X,Y] = meshgrid(x,y);

%  Axis constants. 
xMin = min(x);
xMax = max(x);
yMin = min(y);
yMax = max(y);

%  Number of voltage samples.
Nx = length(x);
Ny = length(y);

%  Capacitor plate parameters.
Vtop = 1;           %  Top capacitor potential (V).
Vbot = -1;          %  Bottom capacitor potential (V).
L    = 1.0;         %  Length (m).
W    = 0.2;         %  Separation width (m).
x1   = -L/2;        %  Left end of plates (m).
x2   = +L/2;        %  Right end of plates (m).
y1   = -W/2;        %  Bottom of electrode.
y2   = +W/2;        %  Top of electrode.

%  Solve for SOR parameters.
Ni = 1000;                              %  Total iterations.
t  = cos(pi/Nx) + cos(pi/Ny);           %  t-parameter.
ww = ( 8 - sqrt(64 - 16*t^2) )/t^2;     %  Relaxation factor.

%==========================================================================
%  Prepare simulation parameters.
%==========================================================================

%  Initialize matrices.
V   = zeros(Ny,Nx);         %  Potential function (V).
BC  = zeros(Ny,Nx);         %  Boundary conditions (boolean).
RHO = zeros(Ny,Nx);         %  Charge distrubution (C/m^2).
EPS = ones(Ny,Nx);          %  Dielectric constants.

%  Initialize boundary conditions.  For this simulation, they are all
%  Dirichlet boundaries.
BC(1,:)   = 1;              %  Top edge
BC(end,:) = 1;              %  Bottom edge
BC(:,1)   = 1;              %  Left edge
BC(:,end) = 1;              %  Right edge

%  Find all points on the plates.
uX1  = (X >= x1);
uX2  = (X <= x2);
uY1  = (Y > y1 - h/2);      %  Bottom plate
uY2  = (Y < y1 + h/2);      
uY3  = (Y > y2 - h/2);      %  Top plate.
uY4  = (Y < y2 + h/2);

%  Calculate matrix indices of the plates.
IDX1 = uX1 & uX2 & uY1 & uY2;       %  Bottom plate.
IDX2 = uX1 & uX2 & uY3 & uY4;       %  Top plate.

%  Set the capacitor plate potentials and boundary conditions.
V( IDX1 )  = Vbot;
V( IDX2 )  = Vtop;
BC( IDX1 ) = 1;
BC( IDX2 ) = 1;

%==========================================================================
%  Numerically solve Poisson's equation for this geometry.  This should
%  take up about 95% of the run-time for this code.
%==========================================================================
V = SOR_Solver(V,BC,RHO,h,ww,Ni);

%==========================================================================
%   Start rendering the potential image.
%==========================================================================
fig = figure(1);
clf
imagesc(x,y,V);
axis([xMin xMax yMin yMax ]);
axis xy;
hold on
axis off;
colormap jet;

%  Tweak the figure to make it look better.
set(fig,'units','normalized','position',[0.1, 0.1, 0.5, 0.5*Ny/Nx]);
set(gca,'Position',[0 0 1 1]);

%==========================================================================
%  Render another identical image, but use E-fields for color.
%==========================================================================

[Ex,Ey,Emag] = staggered_2D_gradient(V,h);
%[Ex,Ey] = gradient(V,h);
Emag = sqrt(Ex.^2 + Ey.^2);
xe = linspace(xMin + h/2,xMax - h/2,Nx-1);
ye = linspace(yMin + h/2,yMax - h/2,Ny-1);

fig = figure(2);
clf
imagesc(xe,ye,Emag);
axis([xMin xMax yMin yMax ]);
hold on
axis off;
colormap jet;


%  Make the figures look nice and pretty.
%  Tweak the figure to make it look better.
set(fig,'units','normalized','position',[0.1, 0.1, 0.5, 0.5*Ny/Nx]);
set(fig,'color','w');           %  Sets background to white.
set(gca,'Position',[0 0 1 1]);  %  Fills up the figure space better.


%==========================================================================
%  Post process to find capacitance per unit length.
%==========================================================================

%  Compute analytical value for capacitance.
e_0 = 8.854e-12;
C_calc = e_0 * L / W;

%  Define vertices of Gaussian contour.  Any random set of points should
%  do.
iYa = round(Ny/2);
iYb = Ny - 20;
iXa = 20;
iXb = Nx - 20;

%  Specify index vectors.
Iy = iYa:iYb;
Ix = iXa:iXb;

q1 = sum( Ex(Iy,iXa) );     %  Right side.
q2 = sum( Ex(Iy,iXb) );     %  Left side
q3 = sum( Ey(iYa,Ix) );     %  Top side
q4 = sum( Ey(iYb,Ix) );     %  bottom side
q  = h*(q1 - q2 + q3 - q4)*e_0;     %  Total charge.

%  Simulated capacitance.
C_sim = q/(Vtop - Vbot);

disp(['Simulated Capacitance  = ' num2str(C_sim*1e12) ' pF']);
disp(['Analytical Capacitance = ' num2str(C_calc*1e12) ' pF']);

%  Verify the contour by tweaking the E-fields and observing the change.
Emag(Iy,iXa) = 20;
Emag(Iy,iXb) = 20;
Emag(iYa,Ix) = 20;
Emag(iYb,Ix) = 20;
figure(3)
clf
imagesc(Emag)
axis xy

